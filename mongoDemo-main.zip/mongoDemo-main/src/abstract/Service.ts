import {Request, Response} from "express";

export abstract class Service{
}