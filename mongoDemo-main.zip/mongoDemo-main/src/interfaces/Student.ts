export interface Student{
    _id?: string,
    userName: string,
    sid?: String,
    name: string,
    department: string,
    grade: string,
    class:string,
    Email: string,
    absences?: number|undefined
}