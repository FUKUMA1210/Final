export interface MongoInfo{
    name:string,
    password:string,
    host:string,
    port:string,
    dbName:string
}