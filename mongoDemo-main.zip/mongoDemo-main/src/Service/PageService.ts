import { Service } from "../abstract/Service";

export class PageService extends Service{

}